import React from 'react';

const CreateEvent = () => {
    return (
        <div>
            create events
        </div>
    );
};

export default CreateEvent;