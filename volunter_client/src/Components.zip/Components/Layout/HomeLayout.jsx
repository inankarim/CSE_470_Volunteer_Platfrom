import React from 'react';

const HomeLayout = () => {
    return (
        <div className=''>
            <p>Home</p>
        </div>
    );
};

export default HomeLayout;